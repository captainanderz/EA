<#

    .SYNOPSIS

    .DESCRIPTION

    .EXAMPLE

    .NOTES
    Author: Morten Rønborg
    Date: 05-11-2018
    Last Updated: 18-11-2020

    After the MSI has been installed the product version is not correcnt in the registry before a Chrome Scheduled task has run. Therefore checking for file version also.
    If Chrome.exe is running during the MSI execution the new_chrome.exe will be created to replace chrome.exe when its closed.

#>

################################################

##Detection variables##
[string]$SoftwareName = "Google Chrome"
[System.Version]$SoftwareVersion = "87.0.4280.66"
[array]$SoftwareFileLocation = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe","$env:ProgramFiles\Google\Chrome\Application\new_chrome.exe")
#######################
$ErrorActionPreference = 'SilentlyContinue'
[string]$LoggedOnConsoleUser = ((Get-WMIObject -class Win32_ComputerSystem | Select-Object Username)[0].Username -Split "\\")[1]
[string]$LoggedOnConsoleUserSID = (Get-ItemProperty -Path  "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\ProfileList\*" | Where-Object {$_.ProfileImagePath -match $LoggedOnConsoleUser}).PSChildName

#Array with locations
$RegistryUninstallPaths = @('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall',`
                            'HKLM:\SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall',`
                            ('HKU:\{0}\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall' -f $LoggedOnConsoleUserSID))

#Map the user hive
if(!(Test-Path -Path HKU:)){
    New-PSDrive HKU -PSProvider Registry -Root HKEY_USERS | Out-Null
}

#Loop through every registry entry
ForEach($RegistryPath in $RegistryUninstallPaths){

    #See if its installed(put into variable to not write to host)
    If($Installed = Get-ChildItem $RegistryPath |  Where-Object {(($_.GetValue('DisplayName') -eq $SoftwareName) -and ([System.Version]$_.GetValue('DisplayVersion') -ge $SoftwareVersion))}){
        
        #Software installed
        Write-Host "The software is installed in '$RegistryPath'"
        Return 0
    }
}

#Loop through every registry entry
ForEach($FileLocation in $SoftwareFileLocation){

    #See if its installed(put into variable to not write to host)
    If(Test-Path -Path $FileLocation){

        #Define fileversion
        [System.Version]$FileVersion = [System.Diagnostics.FileVersionInfo]::GetVersionInfo($FileLocation).FileVersion

        If($FileVersion -ge $SoftwareVersion){
        
            #Software installed
            Write-Host "The file version '$FileVersion' is present on the file '$FileLocation' and is greather than or equal to deisred version '$SoftwareVersion'"
            Return 0
        }
    }
}